import 'package:flutter/material.dart';
class ManualSocialOtpLoginWidget extends StatelessWidget {
  const ManualSocialOtpLoginWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
