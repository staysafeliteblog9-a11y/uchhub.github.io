
enum EnumAddress {
  home,
  office,
  other,
}


