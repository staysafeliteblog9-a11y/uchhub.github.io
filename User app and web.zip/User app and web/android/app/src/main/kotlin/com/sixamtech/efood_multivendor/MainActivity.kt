package com.sixamtech.stackfooduser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
